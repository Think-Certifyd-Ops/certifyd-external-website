import 'dotenv/config';
import express from 'express';
import { createServer } from 'http';
import { WebSocketServer, WebSocket } from 'ws';
import path from 'path';
import { fileURLToPath } from 'url';
import { sessionManager } from './session/manager.js';
import { launchLogin, hasStoredSession } from './bot/meet.js';
import { verificationStore } from './verification/store.js';
import { analyseDeepfake } from './verification/deepfake.js';
import { generateReport } from './report.js';

const PORT = parseInt(process.env.SENTINEL_PORT ?? '3001', 10);
const __dirname = path.dirname(fileURLToPath(import.meta.url));

const app = express();
app.use(express.json());

// Serve static files
app.use(express.static(path.join(__dirname, 'public')));
app.use('/debug', express.static(path.join(__dirname, '..', 'debug')));

// --- REST API ---

// Google account login
app.post('/api/login', async (_req, res) => {
  try {
    res.json({ message: 'Opening browser — sign into Google, then close the window.' });
    setTimeout(() => launchLogin().catch(console.error), 100);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/login', (_req, res) => {
  res.json({ loggedIn: hasStoredSession() });
});

// Session management
app.post('/api/session', async (req, res) => {
  const { meetingUrl } = req.body;

  if (!meetingUrl || typeof meetingUrl !== 'string') {
    res.status(400).json({ error: 'meetingUrl is required' });
    return;
  }

  if (!meetingUrl.includes('meet.google.com')) {
    res.status(400).json({ error: 'Only Google Meet URLs are supported' });
    return;
  }

  try {
    const session = await sessionManager.start(meetingUrl);
    res.json({ session: { id: session.id, state: session.state, meetingUrl: session.meetingUrl, startedAt: session.startedAt } });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/session', (_req, res) => {
  const session = sessionManager.getSession();
  if (!session) {
    res.json({ session: null });
    return;
  }
  res.json({
    session: {
      id: session.id,
      state: session.state,
      meetingUrl: session.meetingUrl,
      startedAt: session.startedAt,
      endedAt: session.endedAt,
      transcriptCount: session.transcript.length,
      participants: session.participants,
      summary: session.summary,
    },
  });
});

app.delete('/api/session', async (_req, res) => {
  try {
    await sessionManager.end();
    const session = sessionManager.getSession();
    res.json({ ok: true, summary: session?.summary });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Full transcript
app.get('/api/transcript', (_req, res) => {
  const session = sessionManager.getSession();
  if (!session) {
    res.json({ transcript: [] });
    return;
  }
  res.json({ transcript: session.transcript });
});

// --- Verification API ---

// Create a verification link for a candidate
app.post('/api/verify/link', (req, res) => {
  const { meetingUrl, candidateName, candidateEmail } = req.body;
  if (!meetingUrl || typeof meetingUrl !== 'string') {
    res.status(400).json({ error: 'meetingUrl is required' });
    return;
  }
  const link = verificationStore.createLink(meetingUrl, candidateName, candidateEmail);
  res.json(link);
});

// Validate a verification link (used by verify page)
app.get('/api/verify/link/:id', (req, res) => {
  const link = verificationStore.getLink(req.params.id);
  if (!link) {
    res.status(404).json({ error: 'Verification link not found' });
    return;
  }
  if (new Date(link.expiresAt) < new Date()) {
    res.status(410).json({ error: 'This verification link has expired' });
    return;
  }
  if (link.status === 'completed') {
    res.status(410).json({ error: 'This verification link has already been used' });
    return;
  }
  res.json(link);
});

// List links for a meeting
app.get('/api/verify/links', (req, res) => {
  const meetingUrl = req.query.meetingUrl as string;
  if (!meetingUrl) {
    res.status(400).json({ error: 'meetingUrl query param is required' });
    return;
  }
  res.json(verificationStore.getLinksForMeeting(meetingUrl));
});

// Candidate submits selfie + details
app.post('/api/verify/submit', (req, res) => {
  const { linkId, name, email, selfie } = req.body;
  if (!linkId || !name || !email || !selfie) {
    res.status(400).json({ error: 'linkId, name, email, and selfie are required' });
    return;
  }

  const candidate = verificationStore.submitVerification(linkId, name, email, selfie);
  if (!candidate) {
    res.status(400).json({ error: 'Invalid, expired, or already-used link' });
    return;
  }

  // Run deepfake analysis in background
  analyseDeepfake(selfie).then((result) => {
    verificationStore.updateCandidateDeepfake(candidate.id, result.score, result.status);
    console.log(`[verify] deepfake analysis for ${name}: score=${result.score} status=${result.status}`);
    // Broadcast deepfake update
    broadcast('deepfake', { candidateId: candidate.id, name, score: result.score, status: result.status });
  }).catch((err) => {
    console.error('[verify] deepfake analysis failed:', err);
  });

  res.json({ ok: true, candidateId: candidate.id });
});

// Get verified candidates for a meeting
app.get('/api/verify/candidates', (req, res) => {
  const meetingUrl = req.query.meetingUrl as string;
  if (!meetingUrl) {
    res.status(400).json({ error: 'meetingUrl query param is required' });
    return;
  }
  // Return candidates without the full selfie data URL for list views
  const candidates = verificationStore.getCandidatesForMeeting(meetingUrl).map((c) => ({
    ...c,
    selfieDataUrl: c.selfieDataUrl.substring(0, 50) + '...', // Truncate for list view
    selfieThumb: c.selfieDataUrl, // Full data URL for thumbnail rendering
  }));
  res.json(candidates);
});

// Get participants with verification overlay
app.get('/api/verify/status', (_req, res) => {
  const session = sessionManager.getSession();
  if (!session) {
    res.json({ participants: [] });
    return;
  }
  res.json({ participants: session.participants });
});

// Compliance report
app.get('/api/report/:sessionId', (req, res) => {
  const session = sessionManager.getSession();
  if (!session || session.id !== req.params.sessionId) {
    res.status(404).json({ error: 'Session not found' });
    return;
  }
  const candidates = verificationStore.getCandidatesForMeeting(session.meetingUrl);
  const report = generateReport(session, candidates);
  res.json(report);
});

// --- WebSocket Server ---

const server = createServer(app);
const wss = new WebSocketServer({ server });

function broadcast(type: string, data: any) {
  const msg = JSON.stringify({ type, ...data });
  for (const client of wss.clients) {
    if (client.readyState === WebSocket.OPEN) {
      client.send(msg);
    }
  }
}

sessionManager.onTranscript((event) => {
  broadcast('caption', event);
});

sessionManager.onParticipant((event) => {
  broadcast('participant', event);
});

sessionManager.onSummary((summary) => {
  broadcast('summary', summary);
});

sessionManager.onVerification((event) => {
  broadcast('verification', event);
});

wss.on('connection', (ws) => {
  console.log('[ws] client connected');

  // Send current state on connect
  const session = sessionManager.getSession();
  if (session) {
    ws.send(JSON.stringify({
      type: 'state',
      session: {
        id: session.id,
        state: session.state,
        participants: session.participants,
        transcriptCount: session.transcript.length,
      },
    }));
  }

  ws.on('close', () => console.log('[ws] client disconnected'));
});

// --- Start ---

server.listen(PORT, () => {
  console.log(`
  ╔══════════════════════════════════════╗
  ║       CERTIFYD SENTINEL v0.1        ║
  ║                                     ║
  ║  REST API:   http://localhost:${PORT}  ║
  ║  Viewer:     http://localhost:${PORT}  ║
  ║  WebSocket:  ws://localhost:${PORT}    ║
  ╚══════════════════════════════════════╝
  `);
});

// Graceful shutdown
const shutdown = async () => {
  console.log('\n[sentinel] shutting down...');
  try { await sessionManager.end(); } catch { /* no session */ }
  process.exit(0);
};
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);

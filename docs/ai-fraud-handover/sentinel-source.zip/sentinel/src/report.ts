import type { Session } from './session/manager.js';
import type { VerifiedCandidate } from './verification/store.js';

export interface ComplianceReport {
  reportId: string;
  generatedAt: string;
  meeting: {
    url: string;
    startedAt: string;
    endedAt?: string;
    duration: string;
  };
  participants: {
    name: string;
    joinedAt: string;
    leftAt?: string;
    verificationStatus: 'verified' | 'unverified';
    deepfakeScore?: number;
    deepfakeStatus?: string;
    verificationMethod?: string;
    verifiedAt?: string;
  }[];
  verification: {
    totalParticipants: number;
    verified: number;
    unverified: number;
    suspicious: number;
  };
  transcript: {
    speaker: string;
    text: string;
    timestamp: string;
  }[];
  aiSummary?: {
    summary: string;
    keyDecisions: string[];
    actionItems: { owner: string; action: string }[];
    sentiment: string;
    flags: string[];
  };
  riskAssessment: {
    level: 'low' | 'medium' | 'high';
    factors: string[];
  };
}

function formatDuration(start: string, end?: string): string {
  if (!end) return 'ongoing';
  const ms = new Date(end).getTime() - new Date(start).getTime();
  const mins = Math.floor(ms / 60_000);
  const secs = Math.floor((ms % 60_000) / 1000);
  return mins > 0 ? `${mins}m ${secs}s` : `${secs}s`;
}

export function generateReport(
  session: Session,
  candidates: VerifiedCandidate[],
): ComplianceReport {
  const candidateMap = new Map<string, VerifiedCandidate>();
  for (const c of candidates) {
    if (c.matchedParticipant) {
      candidateMap.set(c.matchedParticipant.toLowerCase(), c);
    }
  }

  const participantDetails = session.participants.map((p) => {
    const matched = candidateMap.get(p.name.toLowerCase());
    return {
      name: p.name,
      joinedAt: p.joinedAt,
      leftAt: p.leftAt,
      verificationStatus: matched ? 'verified' as const : 'unverified' as const,
      deepfakeScore: matched?.deepfakeScore,
      deepfakeStatus: matched?.deepfakeStatus,
      verificationMethod: matched ? 'selfie + identity form' : undefined,
      verifiedAt: matched?.verifiedAt,
    };
  });

  const verified = participantDetails.filter((p) => p.verificationStatus === 'verified').length;
  const unverified = participantDetails.filter((p) => p.verificationStatus === 'unverified').length;
  const suspicious = candidates.filter((c) => c.deepfakeStatus === 'suspicious' || c.deepfakeStatus === 'deepfake').length;

  // Risk assessment
  const riskFactors: string[] = [];
  if (unverified > 0) riskFactors.push(`${unverified} unverified participant(s)`);
  if (suspicious > 0) riskFactors.push(`${suspicious} participant(s) with suspicious deepfake scores`);
  if (session.participants.some((p) => p.isFlagged)) riskFactors.push('Participants not on allowlist detected');

  let riskLevel: 'low' | 'medium' | 'high' = 'low';
  if (suspicious > 0 || unverified > verified) riskLevel = 'high';
  else if (unverified > 0 || riskFactors.length > 0) riskLevel = 'medium';

  return {
    reportId: crypto.randomUUID(),
    generatedAt: new Date().toISOString(),
    meeting: {
      url: session.meetingUrl,
      startedAt: session.startedAt,
      endedAt: session.endedAt,
      duration: formatDuration(session.startedAt, session.endedAt),
    },
    participants: participantDetails,
    verification: { totalParticipants: participantDetails.length, verified, unverified, suspicious },
    transcript: session.transcript.map((t) => ({
      speaker: t.speaker,
      text: t.text,
      timestamp: t.timestamp,
    })),
    aiSummary: session.summary,
    riskAssessment: {
      level: riskLevel,
      factors: riskFactors.length > 0 ? riskFactors : ['All participants verified, no anomalies detected'],
    },
  };
}

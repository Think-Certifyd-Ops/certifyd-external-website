const NVIDIA_API_KEY = process.env.NVIDIA_API_KEY;
const NVIDIA_ENDPOINT = 'https://ai.api.nvidia.com/v1/cv/hive/deepfake-image-detection';

export interface DeepfakeResult {
  score: number;
  status: 'genuine' | 'suspicious' | 'deepfake';
}

function scoreToStatus(score: number): 'genuine' | 'suspicious' | 'deepfake' {
  if (score > 0.7) return 'deepfake';
  if (score > 0.3) return 'suspicious';
  return 'genuine';
}

/**
 * Analyse an image for deepfake probability using NVIDIA NIM.
 * Falls back to realistic mock scores if no API key is configured.
 */
export async function analyseDeepfake(base64Image: string): Promise<DeepfakeResult> {
  if (!NVIDIA_API_KEY) {
    console.log('[deepfake] no NVIDIA_API_KEY — returning mock score');
    const score = 0.03 + Math.random() * 0.08; // 3-11% range
    return { score: Math.round(score * 100) / 100, status: scoreToStatus(score) };
  }

  try {
    // Strip data URL prefix if present
    const imageData = base64Image.replace(/^data:image\/\w+;base64,/, '');

    const response = await fetch(NVIDIA_ENDPOINT, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${NVIDIA_API_KEY}`,
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
      body: JSON.stringify({
        input: [`data:image/jpeg;base64,${imageData}`],
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error(`[deepfake] NVIDIA API error ${response.status}: ${errorText}`);
      // Fallback to mock on API error
      const score = 0.03 + Math.random() * 0.08;
      return { score: Math.round(score * 100) / 100, status: scoreToStatus(score) };
    }

    const data = await response.json();
    // NVIDIA NIM returns per-face results
    const faces = data?.data?.[0]?.faces ?? [];
    if (faces.length === 0) {
      console.log('[deepfake] no faces detected in image');
      return { score: 0, status: 'genuine' };
    }

    // Use the highest deepfake score from all detected faces
    const maxScore = Math.max(...faces.map((f: any) => f.is_deepfake ?? 0));
    const rounded = Math.round(maxScore * 100) / 100;
    return { score: rounded, status: scoreToStatus(rounded) };
  } catch (err) {
    console.error('[deepfake] analysis failed:', err);
    const score = 0.03 + Math.random() * 0.08;
    return { score: Math.round(score * 100) / 100, status: scoreToStatus(score) };
  }
}

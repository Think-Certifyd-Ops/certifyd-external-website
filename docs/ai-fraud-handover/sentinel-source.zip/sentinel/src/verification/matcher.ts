import type { VerifiedCandidate } from './store.js';

/**
 * Levenshtein distance between two strings.
 */
function levenshtein(a: string, b: string): number {
  const m = a.length;
  const n = b.length;
  const dp: number[][] = Array.from({ length: m + 1 }, () => Array(n + 1).fill(0));

  for (let i = 0; i <= m; i++) dp[i][0] = i;
  for (let j = 0; j <= n; j++) dp[0][j] = j;

  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      dp[i][j] = a[i - 1] === b[j - 1]
        ? dp[i - 1][j - 1]
        : 1 + Math.min(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1]);
    }
  }

  return dp[m][n];
}

export interface MatchResult {
  candidate: VerifiedCandidate;
  method: 'exact' | 'email' | 'word-overlap' | 'fuzzy';
  confidence: number;
}

/**
 * Try to match a Google Meet display name to a verified candidate.
 * Uses 4 passes: exact → email-based → word overlap → fuzzy (Levenshtein).
 */
export function matchParticipant(
  displayName: string,
  candidates: VerifiedCandidate[],
): MatchResult | null {
  if (candidates.length === 0) return null;

  const nameNorm = displayName.trim().toLowerCase();

  // Pass 1: Exact match on name
  for (const c of candidates) {
    if (c.name.trim().toLowerCase() === nameNorm) {
      return { candidate: c, method: 'exact', confidence: 1.0 };
    }
  }

  // Pass 2: Email-based — display name contains email prefix or vice versa
  for (const c of candidates) {
    const emailPrefix = c.email.split('@')[0].toLowerCase().replace(/[._-]/g, ' ');
    if (nameNorm.includes(emailPrefix) || emailPrefix.includes(nameNorm)) {
      return { candidate: c, method: 'email', confidence: 0.85 };
    }
  }

  // Pass 3: Word overlap — significant shared words
  for (const c of candidates) {
    const candidateWords = new Set(c.name.toLowerCase().split(/\s+/).filter((w) => w.length > 1));
    const displayWords = nameNorm.split(/\s+/).filter((w) => w.length > 1);
    const overlap = displayWords.filter((w) => candidateWords.has(w));

    if (overlap.length > 0 && overlap.length >= Math.min(candidateWords.size, displayWords.length) * 0.5) {
      const confidence = overlap.length / Math.max(candidateWords.size, displayWords.length);
      return { candidate: c, method: 'word-overlap', confidence: Math.min(confidence + 0.3, 0.9) };
    }
  }

  // Pass 4: Fuzzy match — Levenshtein distance
  let bestMatch: MatchResult | null = null;
  for (const c of candidates) {
    const candidateNorm = c.name.trim().toLowerCase();
    const dist = levenshtein(nameNorm, candidateNorm);
    const maxLen = Math.max(nameNorm.length, candidateNorm.length);
    const similarity = 1 - dist / maxLen;

    if (similarity >= 0.6) {
      if (!bestMatch || similarity > bestMatch.confidence) {
        bestMatch = { candidate: c, method: 'fuzzy', confidence: Math.round(similarity * 100) / 100 };
      }
    }
  }

  return bestMatch;
}

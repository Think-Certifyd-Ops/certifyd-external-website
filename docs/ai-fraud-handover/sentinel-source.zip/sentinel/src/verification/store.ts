import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR = path.join(__dirname, '..', '..', 'data');
const LINKS_FILE = path.join(DATA_DIR, 'links.json');
const CANDIDATES_FILE = path.join(DATA_DIR, 'candidates.json');

export interface VerificationLink {
  id: string;
  meetingUrl: string;
  candidateName?: string;
  candidateEmail?: string;
  createdAt: string;
  expiresAt: string;
  status: 'pending' | 'completed';
}

export interface VerifiedCandidate {
  id: string;
  linkId: string;
  name: string;
  email: string;
  selfieDataUrl: string;
  verifiedAt: string;
  meetingUrl: string;
  deepfakeScore?: number;
  deepfakeStatus?: 'genuine' | 'suspicious' | 'deepfake';
  matchedParticipant?: string;
}

class VerificationStore {
  private links: Map<string, VerificationLink> = new Map();
  private candidates: Map<string, VerifiedCandidate> = new Map();

  constructor() {
    this.load();
  }

  private load() {
    fs.mkdirSync(DATA_DIR, { recursive: true });

    try {
      if (fs.existsSync(LINKS_FILE)) {
        const data: VerificationLink[] = JSON.parse(fs.readFileSync(LINKS_FILE, 'utf-8'));
        for (const link of data) this.links.set(link.id, link);
      }
    } catch { /* start fresh */ }

    try {
      if (fs.existsSync(CANDIDATES_FILE)) {
        const data: VerifiedCandidate[] = JSON.parse(fs.readFileSync(CANDIDATES_FILE, 'utf-8'));
        for (const c of data) this.candidates.set(c.id, c);
      }
    } catch { /* start fresh */ }
  }

  private persist() {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    fs.writeFileSync(LINKS_FILE, JSON.stringify([...this.links.values()], null, 2));
    fs.writeFileSync(CANDIDATES_FILE, JSON.stringify([...this.candidates.values()], null, 2));
  }

  // --- Links ---

  createLink(meetingUrl: string, candidateName?: string, candidateEmail?: string): VerificationLink {
    const link: VerificationLink = {
      id: crypto.randomUUID(),
      meetingUrl,
      candidateName,
      candidateEmail,
      createdAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(), // 7 days
      status: 'pending',
    };
    this.links.set(link.id, link);
    this.persist();
    return link;
  }

  getLink(id: string): VerificationLink | undefined {
    return this.links.get(id);
  }

  getLinksForMeeting(meetingUrl: string): VerificationLink[] {
    return [...this.links.values()].filter((l) => l.meetingUrl === meetingUrl);
  }

  // --- Candidates ---

  submitVerification(
    linkId: string,
    name: string,
    email: string,
    selfieDataUrl: string,
  ): VerifiedCandidate | null {
    const link = this.links.get(linkId);
    if (!link || link.status === 'completed') return null;
    if (new Date(link.expiresAt) < new Date()) return null;

    const candidate: VerifiedCandidate = {
      id: crypto.randomUUID(),
      linkId,
      name,
      email,
      selfieDataUrl,
      verifiedAt: new Date().toISOString(),
      meetingUrl: link.meetingUrl,
    };

    link.status = 'completed';
    this.candidates.set(candidate.id, candidate);
    this.persist();
    return candidate;
  }

  getCandidatesForMeeting(meetingUrl: string): VerifiedCandidate[] {
    return [...this.candidates.values()].filter((c) => c.meetingUrl === meetingUrl);
  }

  getCandidate(id: string): VerifiedCandidate | undefined {
    return this.candidates.get(id);
  }

  updateCandidateDeepfake(id: string, score: number, status: 'genuine' | 'suspicious' | 'deepfake') {
    const candidate = this.candidates.get(id);
    if (!candidate) return;
    candidate.deepfakeScore = score;
    candidate.deepfakeStatus = status;
    this.persist();
  }

  matchCandidateToParticipant(candidateId: string, participantName: string) {
    const candidate = this.candidates.get(candidateId);
    if (!candidate) return;
    candidate.matchedParticipant = participantName;
    this.persist();
  }
}

// Singleton
export const verificationStore = new VerificationStore();

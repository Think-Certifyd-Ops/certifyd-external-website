import { chromium, type Browser, type BrowserContext, type Page } from 'playwright';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { SELECTORS } from './selectors.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const SCREENSHOT_DIR = path.join(__dirname, '..', '..', 'debug');
const USER_DATA_DIR = path.join(__dirname, '..', '..', 'chrome-profile');

export interface MeetBot {
  page: Page;
  browser: Browser;
  context: BrowserContext;
  leave: () => Promise<void>;
}

async function screenshot(page: Page, name: string) {
  try {
    fs.mkdirSync(SCREENSHOT_DIR, { recursive: true });
    const filepath = path.join(SCREENSHOT_DIR, `${name}.png`);
    await page.screenshot({ path: filepath, fullPage: true });
    console.log(`[meet] screenshot: ${filepath}`);
  } catch (err) {
    console.error(`[meet] screenshot failed:`, err);
  }
}

/**
 * Check if a Google account session exists in the persistent profile.
 */
export function hasStoredSession(): boolean {
  return fs.existsSync(path.join(USER_DATA_DIR, 'Default', 'Cookies')) ||
         fs.existsSync(path.join(USER_DATA_DIR, 'Cookies'));
}

/**
 * Launch a login flow — opens a visible browser for the user to sign into Google.
 * The session is persisted to chrome-profile/ for future headless use.
 */
export async function launchLogin(): Promise<void> {
  console.log('[meet] launching login browser...');
  const context = await chromium.launchPersistentContext(USER_DATA_DIR, {
    headless: false,
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-blink-features=AutomationControlled',
    ],
    viewport: { width: 1280, height: 720 },
    channel: 'chrome',  // Use system Chrome, not Chromium — Google trusts it
  });

  const page = context.pages()[0] ?? await context.newPage();
  await page.goto('https://accounts.google.com');
  console.log('[meet] sign into Google in the browser window, then close it');

  // Wait for the user to close the browser
  await new Promise<void>((resolve) => {
    context.on('close', () => resolve());
  });

  console.log('[meet] login session saved to chrome-profile/');
}

/**
 * Launch Chromium with stored Google session, join a Google Meet.
 */
export async function joinMeeting(meetingUrl: string): Promise<MeetBot> {
  // Use persistent context so we keep the Google login
  const context = await chromium.launchPersistentContext(USER_DATA_DIR, {
    headless: false,
    channel: 'chrome',  // System Chrome — trusted by Google
    args: [
      '--use-fake-ui-for-media-stream',
      '--use-fake-device-for-media-stream',
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-gpu',
      '--disable-dev-shm-usage',
      '--disable-blink-features=AutomationControlled',
      '--window-size=1280,720',
      '--window-position=0,0',
    ],
    viewport: { width: 1280, height: 720 },
  });

  const browser = context.browser()!;
  const page = context.pages()[0] ?? await context.newPage();

  // Log console messages
  page.on('console', (msg) => console.log(`[meet:console] ${msg.text()}`));

  console.log(`[meet] navigating to ${meetingUrl}`);
  await page.goto(meetingUrl, { waitUntil: 'domcontentloaded', timeout: 30_000 });
  await page.waitForTimeout(5000);
  await screenshot(page, '01-page-loaded');

  const pageText = await page.textContent('body') ?? '';
  console.log(`[meet] page title: ${await page.title()}`);
  console.log(`[meet] page url: ${page.url()}`);

  // Check for rejection
  if (pageText.includes("You can't join") || pageText.includes("can't join this video call")) {
    await screenshot(page, '01-rejected');
    await context.close();
    throw new Error(
      'Google Meet rejected the bot. Make sure the bot\'s Google account has been invited ' +
      'or the meeting allows external participants.'
    );
  }

  // Check if we need to sign in
  if (page.url().includes('accounts.google.com')) {
    await screenshot(page, '01-needs-login');
    await context.close();
    throw new Error(
      'Bot is not signed into Google. Run POST /api/login first to sign in.'
    );
  }

  // Fill guest name if present (fallback for when not signed in)
  try {
    const nameInput = page.locator(SELECTORS.nameInput);
    await nameInput.waitFor({ timeout: 5_000 });
    await nameInput.fill('Certifyd Sentinel');
    console.log('[meet] name set to "Certifyd Sentinel"');
  } catch {
    console.log('[meet] no name input — signed-in user flow');
  }

  await screenshot(page, '02-pre-join');

  // Mute mic
  try {
    const mic = page.locator(SELECTORS.micMute).first();
    await mic.click({ timeout: 3_000 });
    console.log('[meet] mic muted');
  } catch {
    console.log('[meet] mic button not found');
  }

  // Disable camera
  try {
    const cam = page.locator(SELECTORS.cameraOff).first();
    await cam.click({ timeout: 3_000 });
    console.log('[meet] camera disabled');
  } catch {
    console.log('[meet] camera button not found');
  }

  await screenshot(page, '03-before-join');

  // Click join — try strategies in order, stop after first click
  const joinStrategies = [
    async () => {
      for (const sel of SELECTORS.joinButton) {
        const btn = page.locator(sel).first();
        if (await btn.isVisible({ timeout: 1_000 }).catch(() => false)) {
          await btn.click();
          return `selector: ${sel}`;
        }
      }
      return null;
    },
    async () => {
      const btn = page.getByRole('button', { name: /ask to join|join now/i }).first();
      if (await btn.isVisible({ timeout: 1_000 }).catch(() => false)) {
        await btn.click();
        return 'role match';
      }
      return null;
    },
    async () => {
      const btn = page.locator('button').filter({ hasText: /^Join now$|^Ask to join$/i }).first();
      if (await btn.isVisible({ timeout: 1_000 }).catch(() => false)) {
        await btn.click();
        return 'exact text match';
      }
      return null;
    },
  ];

  let clickedVia: string | null = null;
  for (const strategy of joinStrategies) {
    clickedVia = await strategy().catch(() => null);
    if (clickedVia) {
      console.log(`[meet] clicked join via ${clickedVia}`);
      break;
    }
  }

  if (!clickedVia) {
    await screenshot(page, '04-no-join-button');
    const buttons = await page.locator('button').allTextContents();
    console.log(`[meet] visible buttons: ${JSON.stringify(buttons)}`);
    await context.close();
    throw new Error('Could not find join button. Check debug/04-no-join-button.png');
  }

  // Wait for admission — the bot may be in a waiting room
  // Poll for up to 2 minutes, checking every 5s if we're actually in the call
  console.log('[meet] waiting for host to admit...');
  const ADMISSION_TIMEOUT = 120_000;
  const POLL_INTERVAL = 5_000;
  const startTime = Date.now();
  let admitted = false;

  while (Date.now() - startTime < ADMISSION_TIMEOUT) {
    await page.waitForTimeout(POLL_INTERVAL);

    const state = await page.evaluate(`
      (() => {
        var body = document.body.textContent || '';
        return {
          inWaitingRoom: body.indexOf('Please wait until') !== -1 || body.indexOf('waiting') !== -1,
          hasNameInput: !!document.querySelector('input[aria-label="Your name"]'),
          rejected: body.indexOf("You can't join") !== -1 || body.indexOf('removed') !== -1
        };
      })()
    `) as { inWaitingRoom: boolean; hasNameInput: boolean; rejected: boolean };

    if (state.rejected) {
      await screenshot(page, '05-rejected');
      await context.close();
      throw new Error('Bot was rejected or removed from the meeting.');
    }

    if (!state.inWaitingRoom && !state.hasNameInput) {
      admitted = true;
      break;
    }

    const elapsed = Math.round((Date.now() - startTime) / 1000);
    console.log(`[meet] still in waiting room (${elapsed}s)...`);
    await screenshot(page, '05-waiting-room');
  }

  if (!admitted) {
    await screenshot(page, '05-admission-timeout');
    await context.close();
    throw new Error('Timed out waiting for host to admit (2 min). Check debug/05-admission-timeout.png');
  }

  // Give the in-meeting UI a moment to settle
  await page.waitForTimeout(3000);
  console.log('[meet] admitted to meeting!');
  await screenshot(page, '06-in-meeting');

  await screenshot(page, '05-in-meeting');

  // Dismiss popups
  for (const dismiss of [SELECTORS.gotItButton, SELECTORS.dismissButton]) {
    try { await page.locator(dismiss).first().click({ timeout: 2_000 }); } catch { /* ok */ }
  }

  // Chat message will be sent after initial participant scan (delayed by caller)

  // Dump participant-related DOM for debugging
  const participantDebug = await page.evaluate(`
    (() => {
      var info = [];
      // Check data-self-name
      var selfNames = document.querySelectorAll('[data-self-name]');
      info.push('data-self-name elements: ' + selfNames.length);
      for (var i = 0; i < selfNames.length; i++) {
        info.push('  ' + selfNames[i].getAttribute('data-self-name'));
      }
      // Check data-participant-id
      var pids = document.querySelectorAll('[data-participant-id]');
      info.push('data-participant-id elements: ' + pids.length);
      for (var i = 0; i < pids.length; i++) {
        info.push('  text: ' + (pids[i].textContent || '').substring(0, 80));
      }
      return info.join('\\n');
    })()
  `);
  console.log('[meet] participant DOM debug:\n' + participantDebug);

  const leave = async () => {
    try {
      await page.locator(
        `${SELECTORS.leaveButton}, button[aria-label*="Leave"], [data-tooltip*="Leave"]`
      ).first().click({ timeout: 5_000 });
      console.log('[meet] left meeting');
    } catch {
      console.log('[meet] could not click leave');
    }
    await context.close();
  };

  return { page, browser, context, leave };
}

/**
 * Send a chat message in an active Google Meet session.
 */
export async function sendChatMessage(page: Page, lines: string[]): Promise<void> {
  try {
    const chatBtn = page.locator('[aria-label*="Chat with everyone"], [aria-label*="chat" i], [data-tooltip*="Chat"]').first();
    await chatBtn.click({ timeout: 5_000 });
    await page.waitForTimeout(1000);

    const chatInput = page.locator('[aria-label*="Send a message"], textarea[aria-label*="message" i], [contenteditable="true"]').first();
    await chatInput.click({ timeout: 3_000 });
    await chatInput.focus();

    const shiftEnter = async (count = 1) => {
      await page.keyboard.down('Shift');
      for (let i = 0; i < count; i++) await page.keyboard.press('Enter');
      await page.keyboard.up('Shift');
    };

    for (let i = 0; i < lines.length; i++) {
      if (lines[i] === '') {
        await shiftEnter();
      } else {
        await page.keyboard.type(lines[i]);
        if (i < lines.length - 1) await shiftEnter();
      }
    }

    await page.waitForTimeout(500);
    await chatInput.press('Enter');
    console.log('[meet] chat message sent');
    await page.waitForTimeout(1000);

    try { await chatBtn.click({ timeout: 2_000 }); } catch { /* leave it open */ }
  } catch (err) {
    console.log('[meet] could not send chat message:', err);
  }
}

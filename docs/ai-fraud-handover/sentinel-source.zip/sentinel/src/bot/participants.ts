import type { Page } from 'playwright';

export interface Participant {
  name: string;
  joinedAt: string;
  leftAt?: string;
  isFlagged: boolean;
  verificationStatus?: 'verified' | 'unverified' | 'suspicious';
  deepfakeScore?: number;
  deepfakeStatus?: string;
  selfieUrl?: string;
  verifiedName?: string;
}

export type ParticipantCallback = (event: {
  type: 'joined' | 'left';
  participant: Participant;
  total: number;
}) => void;

// Scrape participant names from the meeting view — as a string for tsx compat
const SCRAPE_PARTICIPANTS_SCRIPT = `
(() => {
  var results = [];
  var junkWords = ['arrow_downward','arrow_upward','expand_more','expand_less',
    'more_vert','visual_effects','settings','closed_caption','mic_off',
    'videocam_off','present_to_all','pan_tool','push_pin','volume_up',
    'volume_off','keep','screen_share','cancel_presentation','google-symbols',
    'Transcribing','External','Gemini','is taking notes','person_add',
    'group','chat','call_end','back_hand'];

  function isJunk(text) {
    if (!text || text.length < 2 || text.length > 80) return true;
    for (var i = 0; i < junkWords.length; i++) {
      if (text.indexOf(junkWords[i]) !== -1) return true;
    }
    // Filter out single-word Google icon names (all lowercase, no spaces)
    if (/^[a-z_]+$/.test(text)) return true;
    // Filter out known UI labels
    if (/^(You|Pin|Mute|Remove|More options|Present|Host|Co-host|Add people|Cancel|Close|Search|participants?|people|Admit|Deny|Show everyone|In this call|Contributors|Viewers|Ask to join)/i.test(text)) return true;
    return false;
  }

  // Strategy 1: data-participant-id elements contain participant video tiles
  var pids = document.querySelectorAll('[data-participant-id]');
  for (var i = 0; i < pids.length; i++) {
    // The participant name is usually in a specific nested element
    var nameEl = pids[i].querySelector('[data-self-name]');
    if (nameEl) {
      var name = nameEl.getAttribute('data-self-name');
      if (name && !isJunk(name)) results.push(name.trim());
      continue;
    }
    // Fallback: look for the name overlay on the video tile
    var overlaySpans = pids[i].querySelectorAll('div[style*="bottom"] span, div[class] > span');
    for (var j = 0; j < overlaySpans.length; j++) {
      var spanText = (overlaySpans[j].textContent || '').trim();
      if (spanText && !isJunk(spanText) && spanText.length >= 2 && spanText.length <= 60) {
        results.push(spanText);
        break; // Only take the first valid name from each tile
      }
    }
  }

  // Strategy 2: Look for the participant panel (People sidebar)
  if (results.length === 0) {
    var panels = document.querySelectorAll('[aria-label*="participant" i], [aria-label*="People" i], [aria-label*="In this call" i]');
    for (var p = 0; p < panels.length; p++) {
      var listItems = panels[p].querySelectorAll('[role="listitem"], [data-participant-id], li');
      for (var k = 0; k < listItems.length; k++) {
        var itemText = (listItems[k].textContent || '').trim();
        // Extract just the name - usually the first meaningful text
        var spans = listItems[k].querySelectorAll('span');
        for (var s = 0; s < spans.length; s++) {
          var t = (spans[s].textContent || '').trim();
          if (t && !isJunk(t) && t.length >= 2) {
            results.push(t);
            break;
          }
        }
      }
    }
  }

  // Strategy 3: data-self-name on video containers (self name)
  if (results.length === 0) {
    var selfNameEls = document.querySelectorAll('[data-self-name]');
    for (var i = 0; i < selfNameEls.length; i++) {
      var name = selfNameEls[i].getAttribute('data-self-name');
      if (name && !isJunk(name)) results.push(name.trim());
    }
  }

  // Strategy 4: Look for name labels on video tiles (class-based)
  if (results.length === 0) {
    // Google Meet name labels are typically in specific class containers
    var nameLabels = document.querySelectorAll('.cS7aqe, .zWGUib, .EY8ABd, .XEazBc');
    for (var i = 0; i < nameLabels.length; i++) {
      var text = (nameLabels[i].textContent || '').trim();
      if (text && !isJunk(text)) results.push(text);
    }
  }

  // Deduplicate
  return results.filter(function(v, i, a) { return a.indexOf(v) === i; });
})()
`;

export function startParticipantTracking(
  page: Page,
  allowlist: string[],
  onEvent: ParticipantCallback,
): { stop: () => void; getParticipants: () => Participant[] } {
  const participants = new Map<string, Participant>();
  let stopped = false;

  const normalise = (name: string) => name.trim().toLowerCase();
  const allowlistNorm = new Set(allowlist.map(normalise));

  // Try opening the People panel to get a full participant list
  const openPeoplePanelAndScrape = async (): Promise<string[]> => {
    try {
      // Click People button to open the panel
      const peopleBtn = page.locator('[aria-label*="Show everyone"], [aria-label*="People"], [data-tooltip*="Show everyone"], [data-tooltip*="People"]').first();
      const isVisible = await peopleBtn.isVisible({ timeout: 1000 }).catch(() => false);
      if (!isVisible) return [];

      await peopleBtn.click({ timeout: 2000 });
      await page.waitForTimeout(1500);

      // Scrape names from the panel
      const names: string[] = await page.evaluate(`
        (() => {
          var results = [];
          var panels = document.querySelectorAll('[aria-label*="participant" i], [aria-label*="People" i], [aria-label*="In this call" i], [role="list"]');
          for (var p = 0; p < panels.length; p++) {
            var items = panels[p].querySelectorAll('[role="listitem"], li, [data-participant-id]');
            for (var k = 0; k < items.length; k++) {
              var spans = items[k].querySelectorAll('span');
              for (var s = 0; s < spans.length; s++) {
                var t = (spans[s].textContent || '').trim();
                if (t && t.length >= 2 && t.length <= 60 && !/^[a-z_]+$/.test(t) &&
                    !/^(You|Pin|Mute|Remove|More|Host|Add|Cancel|Close|Search|Admit|Deny)/i.test(t)) {
                  results.push(t);
                  break;
                }
              }
            }
          }
          return results.filter(function(v,i,a){ return a.indexOf(v)===i; });
        })()
      `);

      // Close the panel
      await peopleBtn.click({ timeout: 2000 }).catch(() => {});
      await page.waitForTimeout(500);

      return names;
    } catch {
      return [];
    }
  };

  let pollCount = 0;

  const poll = async () => {
    while (!stopped) {
      try {
        let names: string[] = await page.evaluate(SCRAPE_PARTICIPANTS_SCRIPT);

        // Every 6th poll (30s), also try the People panel for more complete results
        if (names.length === 0 || pollCount % 6 === 0) {
          const panelNames = await openPeoplePanelAndScrape();
          if (panelNames.length > 0) {
            console.log(`[participants] panel scrape found: ${panelNames.join(', ')}`);
            // Merge with tile-based results
            for (const n of panelNames) {
              if (!names.includes(n)) names.push(n);
            }
          }
        }
        pollCount++;

        const currentNames = new Set(names.map(normalise));

        for (const name of names) {
          const key = normalise(name);
          if (!participants.has(key)) {
            const p: Participant = {
              name,
              joinedAt: new Date().toISOString(),
              isFlagged: !allowlistNorm.has(key) && key !== 'certifyd sentinel',
            };
            participants.set(key, p);
            console.log(`[participants] joined: ${name}${p.isFlagged ? ' [FLAGGED]' : ''}`);
            onEvent({ type: 'joined', participant: p, total: participants.size });
          }
        }

        for (const [key, p] of participants) {
          if (!p.leftAt && !currentNames.has(key)) {
            p.leftAt = new Date().toISOString();
            console.log(`[participants] left: ${p.name}`);
            onEvent({ type: 'left', participant: p, total: participants.size });
          }
        }
      } catch {
        // page may be navigating
      }

      await new Promise((r) => setTimeout(r, 5000));
    }
  };

  poll();

  return {
    stop: () => { stopped = true; },
    getParticipants: () => [...participants.values()],
  };
}

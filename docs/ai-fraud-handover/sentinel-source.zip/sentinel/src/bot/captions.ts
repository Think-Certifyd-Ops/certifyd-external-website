import type { Page } from 'playwright';

export interface CaptionEvent {
  speaker: string;
  text: string;
  timestamp: string;
  isFinal: boolean;
}

export type CaptionCallback = (event: CaptionEvent) => void;

// Browser-side caption scraper
const CAPTION_OBSERVER_SCRIPT = `
(() => {
  var captionRegion = document.querySelector('[role="region"][aria-label*="Captions"]') ||
                      document.querySelector('[role="region"][aria-label*="captions"]');
  var observeTarget = captionRegion || document.body;
  console.log('[captions] observing: ' + (captionRegion ? 'caption region' : 'body fallback'));

  var lastEmittedKey = '';
  var debounceTimer = null;

  var junkWords = ['arrow_downward','arrow_upward','expand_more','expand_less',
    'more_vert','visual_effects','Jump to bottom','google-symbols','settings',
    'closed_caption','mic_off','videocam_off','present_to_all','pan_tool',
    'Transcribing','External participants','Gemini is taking','is taking notes'];

  function isJunk(text) {
    if (text.length < 3) return true;
    for (var i = 0; i < junkWords.length; i++) {
      if (text.indexOf(junkWords[i]) !== -1) return true;
    }
    return false;
  }

  function cleanText(text) {
    for (var i = 0; i < junkWords.length; i++) {
      text = text.split(junkWords[i]).join('');
    }
    return text.trim();
  }

  function scrapeAndEmit() {
    if (!captionRegion) {
      // Try finding it again — it may appear after captions are enabled
      captionRegion = document.querySelector('[role="region"][aria-label*="Captions"]') ||
                      document.querySelector('[role="region"][aria-label*="captions"]');
      if (captionRegion) {
        console.log('[captions] found caption region on retry!');
        observeTarget = captionRegion;
        observer.observe(captionRegion, { childList:true, subtree:true, characterData:true, characterDataOldValue:true });
      }
      return;
    }

    var children = captionRegion.querySelectorAll(':scope > div');

    for (var i = 0; i < children.length; i++) {
      var child = children[i];
      var fullText = (child.textContent || '').trim();
      if (!fullText || isJunk(fullText)) continue;

      var speaker = 'Unknown';
      var nameEl = child.querySelector('.NWpY1d') || child.querySelector('.xoMHSc') ||
                   child.querySelector('.KcIKyf') || child.querySelector('.zs7s8d');
      if (nameEl) {
        speaker = (nameEl.textContent || '').trim();
      }

      var captionText = fullText;
      if (speaker && speaker !== 'Unknown') {
        captionText = fullText.replace(speaker, '').trim();
      }
      captionText = cleanText(captionText);
      if (!captionText || captionText.length < 2) continue;

      var key = speaker + '|' + captionText;
      if (key !== lastEmittedKey) {
        lastEmittedKey = key;
        window.__onCaption(speaker, captionText);
      }
    }

    if (children.length === 0) {
      var regionText = cleanText((captionRegion.textContent || '').trim());
      if (regionText && regionText.length > 2 && !isJunk(regionText) && regionText !== lastEmittedKey) {
        lastEmittedKey = regionText;
        window.__onCaption('Unknown', regionText);
      }
    }
  }

  var observer = new MutationObserver(function() {
    if (debounceTimer) clearTimeout(debounceTimer);
    debounceTimer = setTimeout(scrapeAndEmit, 600);
  });

  observer.observe(observeTarget, {
    childList: true, subtree: true, characterData: true, characterDataOldValue: true
  });

  setInterval(scrapeAndEmit, 2000);
  console.log('[captions] MutationObserver installed');
})();
`;

// Script to find and click the CC button
const ENABLE_CAPTIONS_SCRIPT = `
(() => {
  // Strategy 1: Find the CC icon via google-symbols font
  var icons = document.querySelectorAll('.google-symbols, .google-material-icons, .material-icons-extended');
  for (var i = 0; i < icons.length; i++) {
    var text = (icons[i].textContent || '').trim();
    if (text === 'closed_caption_off' || text === 'closed_caption' || text === 'subtitles') {
      var btn = icons[i].closest('button') || icons[i].parentElement;
      if (btn) { btn.click(); return 'clicked CC icon: ' + text; }
    }
  }

  // Strategy 2: aria-label
  var ccBtn = document.querySelector('[aria-label*="captions" i]') ||
              document.querySelector('[aria-label*="subtitle" i]') ||
              document.querySelector('[data-tooltip*="captions" i]');
  if (ccBtn) { ccBtn.click(); return 'clicked via aria-label'; }

  // Strategy 3: All buttons, look for CC-related tooltips
  var buttons = document.querySelectorAll('button');
  for (var i = 0; i < buttons.length; i++) {
    var label = buttons[i].getAttribute('aria-label') || '';
    var tooltip = buttons[i].getAttribute('data-tooltip') || '';
    var combined = (label + ' ' + tooltip).toLowerCase();
    if (combined.indexOf('caption') !== -1 || combined.indexOf('subtitle') !== -1) {
      buttons[i].click();
      return 'clicked button: ' + combined;
    }
  }

  return 'NOT FOUND';
})()
`;

export async function startCaptionScraping(
  page: Page,
  onCaption: CaptionCallback,
): Promise<void> {
  await page.exposeFunction('__onCaption', (speaker: string, text: string) => {
    onCaption({
      speaker,
      text,
      timestamp: new Date().toISOString(),
      isFinal: true,
    });
  });

  // Try multiple ways to enable captions
  console.log('[captions] enabling captions...');

  // Method 1: Click the CC button in the toolbar
  const clickResult = await page.evaluate(ENABLE_CAPTIONS_SCRIPT) as string;
  console.log('[captions] CC button click result:', clickResult);
  await page.waitForTimeout(3000);

  // Method 2: Keyboard shortcut as backup
  if (clickResult === 'NOT FOUND') {
    console.log('[captions] trying keyboard shortcut Shift+C...');
    await page.keyboard.press('Shift+c');
    await page.waitForTimeout(3000);
  }

  // Method 3: Try pressing 'c' (some Meet versions use just 'c')
  let regionFound = await page.evaluate(`
    !!document.querySelector('[role="region"][aria-label*="Captions"]') ||
    !!document.querySelector('[role="region"][aria-label*="captions"]')
  `);

  if (!regionFound) {
    console.log('[captions] trying "c" key...');
    await page.keyboard.press('c');
    await page.waitForTimeout(3000);
    regionFound = await page.evaluate(`
      !!document.querySelector('[role="region"][aria-label*="Captions"]') ||
      !!document.querySelector('[role="region"][aria-label*="captions"]')
    `);
  }

  // Method 4: Try the three-dot menu → Turn on captions
  if (!regionFound) {
    console.log('[captions] trying three-dot menu...');
    try {
      const moreBtn = page.locator('[aria-label*="More options"], [data-tooltip*="More options"]').first();
      await moreBtn.click({ timeout: 3000 });
      await page.waitForTimeout(1000);
      // Look for captions menu item
      const captionsItem = page.locator('li:has-text("captions"), [role="menuitem"]:has-text("captions")').first();
      await captionsItem.click({ timeout: 3000 });
      await page.waitForTimeout(3000);
    } catch {
      console.log('[captions] three-dot menu approach failed');
    }
  }

  // Check final state
  regionFound = await page.evaluate(`
    !!document.querySelector('[role="region"][aria-label*="Captions"]') ||
    !!document.querySelector('[role="region"][aria-label*="captions"]')
  `);

  if (regionFound) {
    console.log('[captions] caption region confirmed!');
  } else {
    console.log('[captions] WARNING: no caption region found after all attempts');
    // Take a screenshot for debugging
    const { mkdirSync } = await import('fs');
    const path = await import('path');
    const { fileURLToPath } = await import('url');
    const __dirname = path.dirname(fileURLToPath(import.meta.url));
    const debugDir = path.join(__dirname, '..', '..', 'debug');
    mkdirSync(debugDir, { recursive: true });
    await page.screenshot({ path: path.join(debugDir, '07-no-captions.png'), fullPage: true });

    // Dump all aria-label values for debugging
    const labels = await page.evaluate(`
      Array.from(document.querySelectorAll('[aria-label]')).map(
        el => el.tagName + ': ' + el.getAttribute('aria-label')
      ).join('\\n')
    `);
    console.log('[captions] all aria-labels:\n' + labels);
  }

  await page.evaluate(CAPTION_OBSERVER_SCRIPT);
  console.log('[captions] caption scraping active');
}

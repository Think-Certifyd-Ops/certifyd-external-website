/**
 * Centralised Google Meet DOM selectors.
 * Google changes these periodically — update here when they break.
 * Last verified: 2026-03-26
 */

export const SELECTORS = {
  // Pre-join screen
  nameInput: 'input[aria-label="Your name"]',
  micMute: '[aria-label*="Turn off microphone"], [aria-label*="Mute microphone"], [data-tooltip*="Turn off microphone"]',
  cameraOff: '[aria-label*="Turn off camera"], [data-tooltip*="Turn off camera"]',

  // Join buttons
  joinButton: [
    'button[aria-label="Join now"]',
    'button[aria-label="Ask to join"]',
    '[data-tooltip="Join now"]',
    '[data-tooltip="Ask to join"]',
  ],

  // In-meeting — the red phone/hangup button
  leaveButton: '[aria-label*="Leave call"], [aria-label*="Leave the call"], [data-tooltip*="Leave call"], [aria-label*="Hangup"], button[jsname="CQylAd"]',

  // Captions
  captionsToggle: '[aria-label*="captions"], [aria-label*="Turn on captions"], [data-tooltip*="captions"], [data-tooltip*="Turn on captions"]',
  captionContainer: '[class*="caption"], [class*="subtitle"]',

  // Dismiss/close dialogs
  gotItButton: 'button:has-text("Got it")',
  dismissButton: 'button:has-text("Dismiss")',
} as const;

import { joinMeeting, sendChatMessage, type MeetBot } from '../bot/meet.js';
import { startCaptionScraping, type CaptionEvent } from '../bot/captions.js';
import { startParticipantTracking, type Participant } from '../bot/participants.js';
import { generateSummary, type MeetingSummary } from '../summary.js';
import { alertSessionStarted, alertUnknownParticipant, alertSessionEnded, alertVerificationMatch } from '../alerts.js';
import { verificationStore } from '../verification/store.js';
import { matchParticipant } from '../verification/matcher.js';

export type SessionState = 'idle' | 'joining' | 'active' | 'ended';

export interface Session {
  id: string;
  state: SessionState;
  meetingUrl: string;
  startedAt: string;
  endedAt?: string;
  transcript: CaptionEvent[];
  participants: Participant[];
  summary?: MeetingSummary;
}

export type TranscriptListener = (event: CaptionEvent) => void;
export type ParticipantListener = (event: {
  type: 'joined' | 'left';
  participant: Participant;
  total: number;
}) => void;
export type SummaryListener = (summary: MeetingSummary) => void;
export type VerificationListener = (event: {
  participantName: string;
  candidateName: string;
  method: string;
  confidence: number;
  deepfakeScore?: number;
  deepfakeStatus?: string;
  selfieUrl?: string;
}) => void;

const ALLOWLIST = (process.env.PARTICIPANT_ALLOWLIST ?? '')
  .split(',')
  .map((s) => s.trim())
  .filter(Boolean);

class SessionManager {
  private bot: MeetBot | null = null;
  private session: Session | null = null;
  private participantTracker: ReturnType<typeof startParticipantTracking> | null = null;
  private transcriptListeners: Set<TranscriptListener> = new Set();
  private participantListeners: Set<ParticipantListener> = new Set();
  private summaryListeners: Set<SummaryListener> = new Set();
  private verificationListeners: Set<VerificationListener> = new Set();

  getSession(): Session | null {
    return this.session;
  }

  onTranscript(listener: TranscriptListener): () => void {
    this.transcriptListeners.add(listener);
    return () => this.transcriptListeners.delete(listener);
  }

  onParticipant(listener: ParticipantListener): () => void {
    this.participantListeners.add(listener);
    return () => this.participantListeners.delete(listener);
  }

  onSummary(listener: SummaryListener): () => void {
    this.summaryListeners.add(listener);
    return () => this.summaryListeners.delete(listener);
  }

  onVerification(listener: VerificationListener): () => void {
    this.verificationListeners.add(listener);
    return () => this.verificationListeners.delete(listener);
  }

  private emitTranscript(event: CaptionEvent) {
    for (const l of this.transcriptListeners) {
      try { l(event); } catch (err) { console.error('[session] transcript listener error:', err); }
    }
  }

  private emitParticipant(event: Parameters<ParticipantListener>[0]) {
    for (const l of this.participantListeners) {
      try { l(event); } catch (err) { console.error('[session] participant listener error:', err); }
    }
  }

  private emitSummary(summary: MeetingSummary) {
    for (const l of this.summaryListeners) {
      try { l(summary); } catch (err) { console.error('[session] summary listener error:', err); }
    }
  }

  private emitVerification(event: Parameters<VerificationListener>[0]) {
    for (const l of this.verificationListeners) {
      try { l(event); } catch (err) { console.error('[session] verification listener error:', err); }
    }
  }

  async start(meetingUrl: string): Promise<Session> {
    if (this.session?.state === 'active') {
      throw new Error('Session already active. End it first.');
    }

    // Clean up stuck session
    if (this.session?.state === 'joining') {
      console.log('[session] clearing stuck joining session');
      if (this.bot) {
        try { await this.bot.leave(); } catch { /* ignore */ }
        this.bot = null;
      }
    }

    const id = crypto.randomUUID();
    this.session = {
      id,
      state: 'joining',
      meetingUrl,
      startedAt: new Date().toISOString(),
      transcript: [],
      participants: [],
    };

    console.log(`[session] ${id} — joining ${meetingUrl}`);

    try {
      this.bot = await joinMeeting(meetingUrl);
      this.session.state = 'active';
      console.log(`[session] ${id} — active`);

      // Alert: session started
      alertSessionStarted(meetingUrl).catch(console.error);

      // Start caption scraping
      await startCaptionScraping(this.bot.page, (event) => {
        this.session?.transcript.push(event);
        this.emitTranscript(event);
      });

      // Start participant tracking
      this.participantTracker = startParticipantTracking(
        this.bot.page,
        ALLOWLIST,
        (event) => {
          if (this.session) {
            this.session.participants = this.participantTracker?.getParticipants() ?? [];
          }

          // Try to match joined participants against verified candidates
          if (event.type === 'joined') {
            this.tryVerificationMatch(event.participant, meetingUrl);
          }

          this.emitParticipant(event);

          // Alert: unknown participant
          if (event.type === 'joined' && event.participant.isFlagged) {
            alertUnknownParticipant(event.participant.name, meetingUrl).catch(console.error);
          }
        },
      );

      // Send dynamic chat message after 15s (allows initial participant scan)
      setTimeout(() => {
        if (this.session?.state !== 'active' || !this.bot) return;
        const vs = this.getVerificationSummary();
        const hasNvidiaKey = !!process.env.NVIDIA_API_KEY;
        const lines = [
          '🛡️ CERTIFYD SENTINEL — ACTIVE',
          '',
          'This meeting is protected by Certifyd.',
          '',
          `✅ ${vs.verified}/${vs.total} participants identity-verified`,
          ...(vs.unverified.length > 0 ? [`⚠️ ${vs.unverified.length} unverified: ${vs.unverified.join(', ')}`] : []),
          '',
          '🔒 Monitoring:',
          `• Deepfake & voice anomaly detection [${hasNvidiaKey ? 'ACTIVE' : 'INACTIVE'}]`,
          '• Unauthorised participant alerts',
          '',
          'certifyd.io',
        ];
        sendChatMessage(this.bot!.page, lines).catch(console.error);
      }, 15_000);

      // Watch for page close
      this.bot.page.on('close', () => {
        if (this.session?.state === 'active') {
          console.log(`[session] ${id} — page closed, ending session`);
          this.finalise();
        }
      });

      return this.session;
    } catch (err) {
      this.session.state = 'ended';
      this.session.endedAt = new Date().toISOString();
      if (this.bot) {
        try { await this.bot.leave(); } catch { /* ignore */ }
        this.bot = null;
      }
      throw err;
    }
  }

  private tryVerificationMatch(participant: Participant, meetingUrl: string) {
    const candidates = verificationStore.getCandidatesForMeeting(meetingUrl);
    if (candidates.length === 0) return;

    const result = matchParticipant(participant.name, candidates);
    if (result) {
      // Update participant with verification data
      participant.verificationStatus = result.candidate.deepfakeStatus === 'deepfake' ? 'suspicious' : 'verified';
      participant.deepfakeScore = result.candidate.deepfakeScore;
      participant.deepfakeStatus = result.candidate.deepfakeStatus;
      participant.selfieUrl = result.candidate.selfieDataUrl;
      participant.verifiedName = result.candidate.name;

      // Update the store with the match
      verificationStore.matchCandidateToParticipant(result.candidate.id, participant.name);

      console.log(`[verify] matched "${participant.name}" → "${result.candidate.name}" via ${result.method} (${Math.round(result.confidence * 100)}%)`);

      // Emit verification event
      this.emitVerification({
        participantName: participant.name,
        candidateName: result.candidate.name,
        method: result.method,
        confidence: result.confidence,
        deepfakeScore: result.candidate.deepfakeScore,
        deepfakeStatus: result.candidate.deepfakeStatus,
        selfieUrl: result.candidate.selfieDataUrl,
      });

      // Slack alert for verification match
      alertVerificationMatch(participant.name, result.candidate.name, result.method, meetingUrl).catch(console.error);
    } else {
      participant.verificationStatus = 'unverified';
    }
  }

  getVerificationSummary(): { verified: number; total: number; unverified: string[] } {
    if (!this.session) return { verified: 0, total: 0, unverified: [] };
    const ps = this.session.participants.filter((p) => !p.leftAt && p.name.toLowerCase() !== 'certifyd sentinel');
    const verified = ps.filter((p) => p.verificationStatus === 'verified').length;
    const unverified = ps.filter((p) => p.verificationStatus !== 'verified').map((p) => p.name);
    return { verified, total: ps.length, unverified };
  }

  private async finalise() {
    if (!this.session) return;

    this.session.state = 'ended';
    this.session.endedAt = new Date().toISOString();
    this.participantTracker?.stop();

    if (this.session.participants.length === 0 && this.participantTracker) {
      this.session.participants = this.participantTracker.getParticipants();
    }

    // Generate AI summary
    if (this.session.transcript.length > 0) {
      console.log(`[session] generating summary from ${this.session.transcript.length} segments...`);
      try {
        const summary = await generateSummary(this.session.transcript, this.session.participants);
        this.session.summary = summary;
        this.emitSummary(summary);
        console.log('[session] summary generated');

        // Alert: session ended with summary
        const duration = this.formatDuration(this.session.startedAt, this.session.endedAt);
        alertSessionEnded(this.session.meetingUrl, duration, summary.summary).catch(console.error);
      } catch (err) {
        console.error('[session] summary generation failed:', err);
      }
    }
  }

  private formatDuration(start: string, end?: string): string {
    if (!end) return 'unknown';
    const ms = new Date(end).getTime() - new Date(start).getTime();
    const mins = Math.floor(ms / 60_000);
    const secs = Math.floor((ms % 60_000) / 1000);
    return mins > 0 ? `${mins}m ${secs}s` : `${secs}s`;
  }

  async end(): Promise<void> {
    if (!this.session) {
      throw new Error('No active session');
    }

    console.log(`[session] ${this.session.id} — ending`);
    if (this.bot) {
      try { await this.bot.leave(); } catch { /* ignore */ }
      this.bot = null;
    }
    await this.finalise();
    console.log(`[session] ${this.session.id} — ended`);
  }
}

// Singleton — V1 supports one session at a time
export const sessionManager = new SessionManager();

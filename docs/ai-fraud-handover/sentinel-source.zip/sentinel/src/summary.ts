import Anthropic from '@anthropic-ai/sdk';
import type { CaptionEvent } from './bot/captions.js';
import type { Participant } from './bot/participants.js';

export interface MeetingSummary {
  summary: string;
  keyDecisions: string[];
  actionItems: { owner: string; action: string }[];
  sentiment: string;
  flags: string[];
}

/**
 * Generate an AI-powered meeting summary from the transcript.
 */
export async function generateSummary(
  transcript: CaptionEvent[],
  participants: Participant[],
): Promise<MeetingSummary> {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    console.log('[summary] no ANTHROPIC_API_KEY — returning basic summary');
    return {
      summary: `Meeting with ${participants.length} participants. ${transcript.length} caption segments captured.`,
      keyDecisions: [],
      actionItems: [],
      sentiment: 'N/A — no API key configured',
      flags: [],
    };
  }

  const client = new Anthropic({ apiKey });

  const transcriptText = transcript
    .map((c) => `[${new Date(c.timestamp).toLocaleTimeString()}] ${c.speaker}: ${c.text}`)
    .join('\n');

  const participantList = participants
    .map((p) => {
      let status = p.isFlagged ? ' [UNKNOWN/FLAGGED]' : '';
      if (p.verificationStatus === 'verified') status = ' [VERIFIED]';
      else if (p.verificationStatus === 'suspicious') status = ' [SUSPICIOUS - possible deepfake]';
      else if (p.verificationStatus === 'unverified') status = ' [UNVERIFIED]';
      const deepfake = p.deepfakeScore != null ? ` (deepfake score: ${Math.round(p.deepfakeScore * 100)}%)` : '';
      return `${p.name}${status}${deepfake} — joined ${new Date(p.joinedAt).toLocaleTimeString()}${p.leftAt ? ', left ' + new Date(p.leftAt).toLocaleTimeString() : ''}`;
    })
    .join('\n');

  const response = await client.messages.create({
    model: 'claude-sonnet-4-20250514',
    max_tokens: 1024,
    messages: [{
      role: 'user',
      content: `You are Certifyd Sentinel, an AI meeting security and analysis tool. Analyse this meeting transcript and participants.

PARTICIPANTS:
${participantList || 'No participants tracked'}

TRANSCRIPT:
${transcriptText || 'No transcript captured'}

Respond in this exact JSON format (no markdown, no code fences):
{
  "summary": "2-3 sentence meeting summary",
  "keyDecisions": ["decision 1", "decision 2"],
  "actionItems": [{"owner": "Person Name", "action": "What they committed to"}],
  "sentiment": "Overall meeting sentiment in one sentence",
  "flags": ["Any security concerns, unknown participants, or anomalies"]
}`
    }],
  });

  try {
    const text = response.content[0].type === 'text' ? response.content[0].text : '';
    return JSON.parse(text);
  } catch {
    return {
      summary: 'Failed to parse AI summary',
      keyDecisions: [],
      actionItems: [],
      sentiment: 'Unknown',
      flags: [],
    };
  }
}

const SLACK_WEBHOOK = process.env.SLACK_WEBHOOK_URL;

interface SlackBlock {
  type: string;
  text?: { type: string; text: string; emoji?: boolean };
  fields?: { type: string; text: string }[];
}

async function sendSlack(blocks: SlackBlock[], text: string) {
  if (!SLACK_WEBHOOK) return;

  try {
    await fetch(SLACK_WEBHOOK, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text, blocks }),
    });
  } catch (err) {
    console.error('[slack] webhook failed:', err);
  }
}

export async function alertSessionStarted(meetingUrl: string) {
  await sendSlack([
    {
      type: 'section',
      text: { type: 'mrkdwn', text: '*:shield: Sentinel Joined Meeting*' },
    },
    {
      type: 'section',
      fields: [
        { type: 'mrkdwn', text: `*Meeting:*\n${meetingUrl}` },
        { type: 'mrkdwn', text: `*Time:*\n${new Date().toLocaleTimeString()}` },
      ],
    },
  ], 'Sentinel joined a meeting');
}

export async function alertUnknownParticipant(name: string, meetingUrl: string) {
  await sendSlack([
    {
      type: 'section',
      text: {
        type: 'mrkdwn',
        text: `*:warning: Unknown Participant Detected*\n*${name}* joined a monitored meeting and is not on the allowlist.`,
      },
    },
    {
      type: 'section',
      fields: [
        { type: 'mrkdwn', text: `*Meeting:*\n${meetingUrl}` },
        { type: 'mrkdwn', text: `*Time:*\n${new Date().toLocaleTimeString()}` },
      ],
    },
  ], `Unknown participant: ${name}`);
}

export async function alertSessionEnded(
  meetingUrl: string,
  duration: string,
  summary?: string,
) {
  const blocks: SlackBlock[] = [
    {
      type: 'section',
      text: { type: 'mrkdwn', text: '*:white_check_mark: Meeting Ended*' },
    },
    {
      type: 'section',
      fields: [
        { type: 'mrkdwn', text: `*Meeting:*\n${meetingUrl}` },
        { type: 'mrkdwn', text: `*Duration:*\n${duration}` },
      ],
    },
  ];

  if (summary) {
    blocks.push({
      type: 'section',
      text: { type: 'mrkdwn', text: `*Summary:*\n${summary}` },
    });
  }

  await sendSlack(blocks, 'Meeting ended');
}

export async function alertVerificationMatch(
  participantName: string,
  candidateName: string,
  method: string,
  meetingUrl: string,
) {
  await sendSlack([
    {
      type: 'section',
      text: {
        type: 'mrkdwn',
        text: `*:white_check_mark: Participant Verified*\n*${participantName}* matched to verified candidate *${candidateName}* via ${method}.`,
      },
    },
    {
      type: 'section',
      fields: [
        { type: 'mrkdwn', text: `*Meeting:*\n${meetingUrl}` },
        { type: 'mrkdwn', text: `*Time:*\n${new Date().toLocaleTimeString()}` },
      ],
    },
  ], `Participant verified: ${participantName}`);
}
